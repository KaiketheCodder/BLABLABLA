from flask import Flask, render_template

app = Flask (__name__)

@app.route('/inicio')
def hello():
    return "<h1> Hello World!</h1>"

@app.route('/Jorge')
def listarmusicas():
    lista = ['Girl inform me, Modern Leper, Tears over beers']
    return render_template('listar_musicas.html', titulo = "Músicas preferidas do Momento: ", musicas = lista)
    
app.run(debug = True)